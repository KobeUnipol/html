<?php 

$server='localhost';
$user='root';
$pass='Partyhorse1';
$db='login';

$conn=mysqli_connect($server,$user,$pass,$db);

if(!$conn){
	die('Conexión fallida');
}



?>