<?php

$server ='localhost';
$user ='root';
$pass ='Partyhorse1';
$db='login';

 $conexion = mysqli_connect($dbser, $user, $pass, $db); 
 
 if($conexion){
    echo "Conexión establecida!!";
 }else{
    echo "Kobe es puto y el osvi tambien :D!!";
 }
 $insertar = mysql_query("INSERT INTO usuarios (name) VALUES ('ALFREDO')");

 if($insertar){
   echo "hecho";
 }else{
   echo "no se hizo";
 }

?>