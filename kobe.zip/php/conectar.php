<?php
$server ='localhost';
$user ='root';
$pass ='Partyhorse1';
$db='login';

 $conexion = mysqli_connect($dbser, $user, $pass, $db); 
 if (!$conexion){
    die("fallo la conexion" . mysql_error());
 }

$name = $_POST['name'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];
$birthday = $_POST['birthday'];

 $insertar = mysql_query("INSERT INTO usuarios (name, email, username, password, gender, phone, birthday) VALUES ('$name' , '$email' , '$username' , '$password' , '$gender' , '$phone' ,'$birthday')");
if($insertar){
   echo "si se hizo";
}else{
   echo "no se hizo";
}
 mysqli_close($conexion)

?>